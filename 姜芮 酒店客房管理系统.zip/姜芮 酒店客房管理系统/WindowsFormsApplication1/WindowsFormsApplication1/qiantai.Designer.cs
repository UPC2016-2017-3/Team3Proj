﻿namespace WindowsFormsApplication1
{
    partial class qiantai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(qiantai));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.查询房源信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询房源信息ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.录入客人信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.录入客户信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.改变房间信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.改变房源信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询房源信息ToolStripMenuItem,
            this.录入客户信息ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(627, 29);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 查询房源信息ToolStripMenuItem
            // 
            this.查询房源信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询房源信息ToolStripMenuItem1,
            this.录入客人信息ToolStripMenuItem,
            this.改变房源信息ToolStripMenuItem});
            this.查询房源信息ToolStripMenuItem.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.查询房源信息ToolStripMenuItem.Name = "查询房源信息ToolStripMenuItem";
            this.查询房源信息ToolStripMenuItem.Size = new System.Drawing.Size(86, 25);
            this.查询房源信息ToolStripMenuItem.Text = "入住管理";
            // 
            // 查询房源信息ToolStripMenuItem1
            // 
            this.查询房源信息ToolStripMenuItem1.Name = "查询房源信息ToolStripMenuItem1";
            this.查询房源信息ToolStripMenuItem1.Size = new System.Drawing.Size(176, 26);
            this.查询房源信息ToolStripMenuItem1.Text = "查询房源信息";
            this.查询房源信息ToolStripMenuItem1.Click += new System.EventHandler(this.查询房源信息ToolStripMenuItem1_Click);
            // 
            // 录入客人信息ToolStripMenuItem
            // 
            this.录入客人信息ToolStripMenuItem.Name = "录入客人信息ToolStripMenuItem";
            this.录入客人信息ToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.录入客人信息ToolStripMenuItem.Text = "录入客人信息";
            this.录入客人信息ToolStripMenuItem.Click += new System.EventHandler(this.录入客人信息ToolStripMenuItem_Click);
            // 
            // 录入客户信息ToolStripMenuItem
            // 
            this.录入客户信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.改变房间信息ToolStripMenuItem});
            this.录入客户信息ToolStripMenuItem.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.录入客户信息ToolStripMenuItem.Name = "录入客户信息ToolStripMenuItem";
            this.录入客户信息ToolStripMenuItem.Size = new System.Drawing.Size(86, 25);
            this.录入客户信息ToolStripMenuItem.Text = "退宿管理";
            this.录入客户信息ToolStripMenuItem.Click += new System.EventHandler(this.录入客户信息ToolStripMenuItem_Click);
            // 
            // 改变房间信息ToolStripMenuItem
            // 
            this.改变房间信息ToolStripMenuItem.Name = "改变房间信息ToolStripMenuItem";
            this.改变房间信息ToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.改变房间信息ToolStripMenuItem.Text = "改变房间信息";
            this.改变房间信息ToolStripMenuItem.Click += new System.EventHandler(this.改变房间信息ToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(483, 386);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 27);
            this.button1.TabIndex = 3;
            this.button1.Text = "回到主界面";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // 改变房源信息ToolStripMenuItem
            // 
            this.改变房源信息ToolStripMenuItem.Name = "改变房源信息ToolStripMenuItem";
            this.改变房源信息ToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.改变房源信息ToolStripMenuItem.Text = "录入房间信息";
            this.改变房源信息ToolStripMenuItem.Click += new System.EventHandler(this.改变房源信息ToolStripMenuItem_Click);
            // 
            // qiantai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(627, 497);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "qiantai";
            this.Text = "前台";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 查询房源信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 录入客户信息ToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem 查询房源信息ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 改变房间信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 录入客人信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 改变房源信息ToolStripMenuItem;
    }
}