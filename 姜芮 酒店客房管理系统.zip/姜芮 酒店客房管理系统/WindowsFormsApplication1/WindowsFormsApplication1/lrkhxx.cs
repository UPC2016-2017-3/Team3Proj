﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public partial class lrkhxx : Form
    {

        private string sql = "";
        public lrkhxx()
        {
            InitializeComponent();
        }

        private void DataBinding()
        {
            //this.dataGridView1.Dock = DockStyle.Fill;
            //this.dataGridView1.DataSource = this.bindingSource1;
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            DataSet ret = new DataSet();
            using (SqlConnection cnn = new SqlConnection(connStr))
            {
                cnn.Open();
                string queryString = "select * from Customer and Room";
                
                SqlDataAdapter ad = new SqlDataAdapter();
                SqlCommand com = new SqlCommand(queryString, cnn);
                com.CommandType = CommandType.Text;
                ad.SelectCommand = com;
                ad.Fill(ret);
            }
            //bindingSource1.DataSource = ret.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            string _sql = "select count(*) from Customer where Cid='" + textBox1.Text + "' and Name='" + textBox2.Text + "' and Livetime='" + textBox3.Text + "'and Rid='"+textBox4.Text+"'";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            //检查是否有该记录，有就关闭连接，无则添加
            try
            {
                conn.Open();
                int cnt = (int)cmd.ExecuteScalar();
                //
                if (cnt == 1)
                {
                    MessageBox.Show("已有该记录", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                //添加新记录
                else
                {
                    string strRoomid = textBox4.Text.ToString().Trim();
                    string sql = "update Room set  Iscleaning ='未清洁',Isliving ='在住' where Rid='" + strRoomid + "'";
                    string _sql2 = "insert into Customer(Cid,Name,Livetime,Rid)values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";

                    SqlCommand cmd2 = new SqlCommand(_sql2, conn);

                    cmd2.ExecuteNonQuery();

                    string _sql3 = "select * from Customer ";
                    SqlDataAdapter sda = new SqlDataAdapter(_sql3, conn);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0].DefaultView;
                    MessageBox.Show("添加成功！",
                                     "提示",
                                     MessageBoxButtons.OK,
                                     MessageBoxIcon.Information);
                    
                }
            }
            finally
            {
                conn.Close();
            }
        }

        private void lrkhxx_Load(object sender, EventArgs e)
        {
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            string _sql = "select Cid as '身份证号',Name as '名字',Livetime as '入住时间',Rid as '房间号' from Customer";
            SqlConnection conn = new SqlConnection(connStr);
            SqlDataAdapter sda = new SqlDataAdapter(_sql, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0].DefaultView;

        }
        //private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        //{

        //    DataGridViewRow dgvRow = dataGridView1.Rows[e.RowIndex];
        //    DataGridViewCellCollection dgvcc = dgvRow.Cells;
        //    textBox1.Text = dgvcc[0].Value.ToString();
        //    textBox2.Text = dgvcc[1].Value.ToString();
        //    textBox3.Text = dgvcc[2].Value.ToString();
        //    textBox4.Text = dgvcc[3].Value.ToString();


        //}
     

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            qiantai a = new qiantai();
            a.Show();
        }

        private void 删除_Click(object sender, EventArgs e)
        {
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            DialogResult ret = MessageBox.Show("确定要删除记录吗？",
                                               "删除",
                                               MessageBoxButtons.OKCancel,
                                               MessageBoxIcon.Question);
            if (ret == DialogResult.OK)
            {
                string _sql  = "select Cid as '身份证号',Name as '名字',Livetime as '入住时间',Rid as '房间号' from Customer";
                SqlConnection conn = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand(_sql, conn);
                conn.Open();
                string _sql2 = "delete from Customer where Cid='" + textBox1.Text + "'";
                SqlCommand cmd2 = new SqlCommand(_sql2, conn);
                cmd2.ExecuteNonQuery();
                string _sql3 = "select  Cid as '身份证号',Name as '名字',Livetime as '入住时间',Rid as '房间号' from Customer ";
                SqlDataAdapter sda = new SqlDataAdapter(_sql3, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                MessageBox.Show("删除成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                conn.Close();
            }
        }

        private void dataGridView1_RowHeaderMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow dgvRow = dataGridView1.Rows[e.RowIndex];
            DataGridViewCellCollection dgvcc = dgvRow.Cells;
            textBox1.Text = dgvcc[0].Value.ToString();
            textBox2.Text = dgvcc[1].Value.ToString();
            textBox3.Text = dgvcc[2].Value.ToString();
            textBox4.Text = dgvcc[3].Value.ToString();
        }
    }
}
