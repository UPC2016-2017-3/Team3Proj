﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public partial class room : Form
    {
        public room()
        {
            InitializeComponent();
        }
        private void DataBinding()
        {
            //this.dataGridView1.Dock = DockStyle.Fill;
            //this.dataGridView1.DataSource = this.bindingSource1;
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            DataSet ret = new DataSet();
            using (SqlConnection cnn = new SqlConnection(connStr))
            {
                cnn.Open();
                string queryString = "select * from Room";
                SqlDataAdapter ad = new SqlDataAdapter();
                SqlCommand com = new SqlCommand(queryString, cnn);
                com.CommandType = CommandType.Text;
                ad.SelectCommand = com;
                ad.Fill(ret);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            qiantai a = new qiantai();
            a.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strIscleaning = comboBox1.Text.ToString().Trim();
            string strRoomid = textBox1.Text.ToString().Trim();
            string strIsliving = comboBox2.Text.ToString().Trim();
            if (strRoomid == "") { }
            else
            {
                string sql = "update Room set  Iscleaning ='" + strIscleaning + "',Isliving ='" + strIsliving + "' where Rid='" + strRoomid + "'";
                SqlConnection connection = new SqlConnection("Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True");
                connection.Open();            //打开数据库
                SqlCommand command = new SqlCommand(sql, connection);   // 创建一个SqlCommand对象command对数据库进行操作                                         
                command.ExecuteNonQuery();

                connection.Close();  //关闭数据库连接
            }

        }
    }
}
