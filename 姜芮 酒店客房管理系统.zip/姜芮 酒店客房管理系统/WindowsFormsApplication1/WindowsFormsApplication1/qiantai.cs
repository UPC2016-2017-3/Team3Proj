﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class qiantai : Form
    {
        public qiantai()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            land a = new land();
            a.Show();
        }

        private void 查询房源信息ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            cxfy a = new cxfy();
            a.Show();
        }
        private void 录入客户信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
       

        private void 改变房间信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            room c = new room();
            c.Show();
        }

        private void 录入客人信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            lrkhxx d = new lrkhxx();
            d.Show();
        }

        private void 改变房源信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            room c = new room();
            c.Show();
        }

        
    }
}
