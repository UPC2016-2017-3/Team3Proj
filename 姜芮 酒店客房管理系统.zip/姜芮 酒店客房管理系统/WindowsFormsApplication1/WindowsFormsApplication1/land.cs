﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class land : Form
    {
        SqlConnection sqlCon = new SqlConnection();

        SqlCommand sqlCmd = new SqlCommand();

        String id = "";

        public land()
        {
            InitializeComponent();
        }

        private void land_Load(object sender, EventArgs e)
        {
            sqlCon.ConnectionString = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            sqlCon.Open();


            //comboBox1.Items.Clear();  //每次事件开始就清空控件

            sqlCmd.Connection = sqlCon;

            sqlCmd.CommandText = "select *from Login";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            sqlCmd.CommandText = "select * from Worker where Wid='" + this.textBox1.Text + "' and password='" + this.textBox2.Text + "'and Type='" + this.comboBox1.Text + "'";
            sqlCmd.Connection = sqlCon;

            SqlDataReader sqlDr = sqlCmd.ExecuteReader();

            if (sqlDr.Read())
            {
                if (this.comboBox1.Text.Equals("前台"))
                {
                    this.Hide();
                    id = this.textBox1.Text;
                    qiantai NewFrm = new qiantai();
                    NewFrm.Show();
                }
                if (this.comboBox1.Text.Equals("保洁员"))
                {
                    this.Hide();
                    id = this.textBox1.Text;
                    cleaner NewFrm = new cleaner();
                    NewFrm.Show();
                }


            }
        }
    }
}