﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public partial class cxfy : Form
    {
        public cxfy()
        {
            InitializeComponent();
        }
        private void DataBinding()
        {
            //this.dataGridView1.Dock = DockStyle.Fill;
            //this.dataGridView1.DataSource = this.bindingSource1;
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            DataSet ret = new DataSet();
            using (SqlConnection cnn = new SqlConnection(connStr))
            {
                cnn.Open();
                string queryString = "select * from Room";
                SqlDataAdapter ad = new SqlDataAdapter();
                SqlCommand com = new SqlCommand(queryString, cnn);
                com.CommandType = CommandType.Text;
                ad.SelectCommand = com;
                ad.Fill(ret);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            string _sql = "select * from Room where Iscleaning='" + comboBox1.Text + "' and Isliving='" + comboBox2.Text + "' and Rtype='" + comboBox3.Text + "'";
            DataSet ret = new DataSet();
            using (SqlConnection cnn = new SqlConnection(connStr))
            {
                cnn.Open();
                string queryString = _sql;
                SqlDataAdapter ad = new SqlDataAdapter();
                SqlCommand com = new SqlCommand(queryString, cnn);
                com.CommandType = CommandType.Text;
                
                ad.SelectCommand = com;
                ad.Fill(ret);

                dataGridView1.DataSource = ret.Tables[0];

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            DataGridViewRow dgvRow = dataGridView1.Rows[e.RowIndex];
            DataGridViewCellCollection dgvcc = dgvRow.Cells;
            comboBox1.Text = dgvcc[0].Value.ToString();
            comboBox2.Text = dgvcc[1].Value.ToString();
            comboBox3.Text = dgvcc[2].Value.ToString();


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            qiantai a = new qiantai();
            a.Show();
        }

       
       
    }
}
