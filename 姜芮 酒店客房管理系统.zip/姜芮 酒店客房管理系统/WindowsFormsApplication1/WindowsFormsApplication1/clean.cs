﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public partial class clean : Form
    {
        public clean()
        {
            InitializeComponent();
        }
        private void DataBinding()
        {
            //this.dataGridView1.Dock = DockStyle.Fill;
            //this.dataGridView1.DataSource = this.bindingSource1;
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            DataSet ret = new DataSet();
            using (SqlConnection cnn = new SqlConnection(connStr))
            {
                cnn.Open();
                string queryString = "select * from Room";
                SqlDataAdapter ad = new SqlDataAdapter();
                SqlCommand com = new SqlCommand(queryString, cnn);
                com.CommandType = CommandType.Text;
                ad.SelectCommand = com;
                ad.Fill(ret);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connStr = "Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True";
            string _sql = "select * from Room where Iscleaning='未清洁'";
            DataSet ret = new DataSet();
            using (SqlConnection cnn = new SqlConnection(connStr))
            {
                cnn.Open();
                string queryString = _sql;
                SqlDataAdapter ad = new SqlDataAdapter();
                SqlCommand com = new SqlCommand(queryString, cnn);
                com.CommandType = CommandType.Text;

                ad.SelectCommand = com;
                ad.Fill(ret);

                dataGridView1.DataSource = ret.Tables[0];
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string strRoomid= textBox1.Text.ToString().Trim();
            if (strRoomid == "") { }
            else
            {
                string sql = "update Room set  Iscleaning ='已请洁' where Rid='" + strRoomid + "'";
                SqlConnection connection = new SqlConnection("Data Source=WIN-84JQOMORBN1\\JR;Initial Catalog=JDGL;Integrated Security=True");
                connection.Open();            //打开数据库
                SqlCommand command = new SqlCommand(sql, connection);   // 创建一个SqlCommand对象command对数据库进行操作                                         
                command.ExecuteNonQuery();

                connection.Close();  //关闭数据库连接
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            cleaner a = new cleaner();
            a.Show();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

