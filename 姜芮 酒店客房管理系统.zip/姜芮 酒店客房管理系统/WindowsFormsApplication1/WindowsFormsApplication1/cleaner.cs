﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class cleaner : Form
    {
        public cleaner()
        {
            InitializeComponent();
        }

        private void 查询清洁信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            clean a = new clean();
            a.Show();
        }

        private void cleaner_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            land a = new land();
            a.Show();
        }
    }
}
